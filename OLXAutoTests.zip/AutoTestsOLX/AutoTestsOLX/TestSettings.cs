﻿namespace AutoTestsOLX
{
    class TestSettings
    {
        public const string HostPrefix = "https://www.olx.ua/";
        public const string login = "rockman909@rambler.ru";
        public const string password = "mostwanted1";
        public const string wrongPassword = "mostwanted2";
        public const string wrongLoginNumberPhone = "+389999897192";
    }
}

