using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using NUnit.Framework.Internal;
using OpenQA.Selenium.Chrome;
using System;
using OpenQA.Selenium.Support.UI;
using AutoTestsOLX;



namespace AutoTestsOLXAuthentication
{
    public class AuthenticationTests
    {
        private static IWebDriver driver;

        private readonly By _singInButton = By.Id("topLoginLink");
        private readonly By _loginInputButton = By.Id("userEmail");
        private readonly By _closecookies = By.CssSelector(".cookie-close");
        private readonly By _passwordInputButton = By.Id("userPass");
        private readonly By _enter = By.Id("se_userLogin");
        private readonly By _topLoginLink = By.Id("topLoginLink");
        private readonly By _logout = By.Id("login-box-logout");

        [SetUp]
        public void Setup()
        {

            driver = new ChromeDriver();
            driver.Navigate().GoToUrl(TestSettings.HostPrefix);
            driver.Manage().Window.Maximize();
        }

        [Test]
        public void LoginDataCorrectViaClick()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(d => d.FindElement(_loginInputButton));
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.login);
            driver.FindElement(_passwordInputButton).Clear();
            driver.FindElement(_passwordInputButton).SendKeys(TestSettings.password);
            driver.FindElement(_enter).Click();
            wait.Until(d => d.FindElement(_topLoginLink));
            Actions builder = new Actions(driver);
            IWebElement myProfileLink = driver.FindElement(_topLoginLink);
            builder.MoveToElement(myProfileLink).Build().Perform();

            Assert.IsTrue(driver.Url.Contains("/myaccount/#login"));
            Assert.IsTrue(driver.FindElement(By.Id("userLoginBox")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".paybalance-box__inner a:nth-child(2)")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".header-buy-package__container a:first-child")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".tabs2.clr li.fleft span.fleft")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountAnswers")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountWallet")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountShop")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector("#delivery-usertab a")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountBusiness")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("typeactive")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("typearchive")).Displayed);
        }

        [Test]
        public void LoginDataCorrectViaEnterKey()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(d => d.FindElement(_loginInputButton));
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.login);
            driver.FindElement(_passwordInputButton).Clear();
            driver.FindElement(_passwordInputButton).SendKeys(TestSettings.password);
            driver.FindElement(_enter).SendKeys(Keys.Enter);
            wait.Until(d => d.FindElement(_topLoginLink));
            Actions builder = new Actions(driver);
            IWebElement myProfileLink = driver.FindElement(_topLoginLink);
            builder.MoveToElement(myProfileLink).Build().Perform();

            Assert.IsTrue(driver.Url.Contains("/myaccount/#login"));
            Assert.IsTrue(driver.FindElement(By.Id("userLoginBox")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".paybalance-box__inner a:nth-child(2)")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".header-buy-package__container a:first-child")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".tabs2.clr li.fleft span.fleft")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountAnswers")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountWallet")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountShop")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector("#delivery-usertab a")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("se_accountBusiness")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("typeactive")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("typearchive")).Displayed);
        }

        [Test]
        public void LoginIncorrectFormat()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.password + TestSettings.password);
            driver.FindElement(_passwordInputButton).Click();

            string actualResult = driver.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")).Text;

            Assert.AreEqual("������������ ������ email ��� ������ ��������", actualResult);
        }
        [Test]
        public void PhoneNumberIncorrect()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.wrongLoginNumberPhone);
            driver.FindElement(_passwordInputButton).Clear();
            driver.FindElement(_passwordInputButton).SendKeys(TestSettings.password);
            driver.FindElement(_enter).Click();

            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(d => d.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")));
            string actualResult = driver.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")).Text;

            Assert.AreEqual("������� ������ ����� ��������", actualResult);
        }

        [Test]
        public void EmailOrPhoneEmpty()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            driver.FindElement(_passwordInputButton).Clear();
            driver.FindElement(_passwordInputButton).SendKeys(TestSettings.password);
            driver.FindElement(_enter).Click();

            string actualResult = driver.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")).Text;

            Assert.AreEqual("���� ����������� ��� ����������", actualResult);
        }

        [Test]
        public void PasswordIncorrect()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.login);
            driver.FindElement(_passwordInputButton).Clear();
            driver.FindElement(_passwordInputButton).SendKeys(TestSettings.wrongPassword);
            driver.FindElement(_enter).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(d => d.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")));

            string actualResult = driver.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")).Text;
            Assert.AreEqual("�������� ������", actualResult);
        }

        [Test]
        public void PasswordEmpty()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.login);
            driver.FindElement(_enter).Click();

            string actualResult = driver.FindElement(By.Id("se_emailError")).FindElement(By.CssSelector(".error")).Text;

            Assert.AreEqual("���� ����������� ��� ����������", actualResult);
        }

        [Test]
        public void Logout()
        {
            driver.FindElement(_closecookies).Click();
            driver.FindElement(_singInButton).Click();
            driver.FindElement(_loginInputButton).Clear();
            driver.FindElement(_loginInputButton).SendKeys(TestSettings.login);
            driver.FindElement(_passwordInputButton).Clear();
            driver.FindElement(_passwordInputButton).SendKeys(TestSettings.password);
            driver.FindElement(_enter).Click();
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until(d => d.FindElement(_topLoginLink));
            Actions builder = new Actions(driver);
            IWebElement myProfileLink = driver.FindElement(_topLoginLink);
            builder.MoveToElement(myProfileLink).Build().Perform();
            driver.FindElement(_logout).Click();

            wait.Until(d => d.FindElement(By.Id("headerLogo")));
            Assert.IsTrue(driver.FindElement(By.Id("headerLogo")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("observed-search-link")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("topLoginLink")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("postNewAdLink")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("headerSearch")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("cityField")).Displayed);
            Assert.IsTrue(driver.FindElement(By.Id("submit-searchmain")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".maincategories")).Displayed);
            Assert.IsTrue(driver.FindElement(By.CssSelector(".tright")).Displayed);
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }
    }
}